Explanation of files that may be included in this zip package:

.mod       P-SPICE MACROMODEL FILE
.sch       SCHEMATIC EXAMPLE
.slb       SYMBOL FILE FOR P-SPICE DESIGN CENTER(R)MICROSIM CORP
