Please read before using the OSRAM PSpice libraries!


- Only the typical forward characteristic (Vf-If diagram) of each LED has been modelled.

- The typical forward characteristic can vary slightly in reality.

- All other Pspice parameters have not been modelled (e.g. reverse characteristic, transient behaviour).

- For this reason, transient simulations and simulations in reverse direction do not make sense.

- The models only work at a Ambient Temperature of 25�C.
  The PSpice parameters are calculated from measured forward voltage values. 
  Forward voltages are tested at a current pulse duration of 1 ms and a tolerance of +- 0.1V.
  Simulations at different temperatures and drive conditions will give wrong simulation results.

- The provided PSpice parameters are calculated values. They might not be identical with
  the real physical values.



